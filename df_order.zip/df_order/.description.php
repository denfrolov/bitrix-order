<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = array(
	'NAME' => 'Оформление заказа',
	'DESCRIPTION' => 'Оформление заказа от Дениса Фролова',
	'PATH' => array(
		'ID' => 'Denis Frolov'
	)
);
<?$MESS["EMAIL"] = "email";
$MESS["PHONE"] = "телефон";

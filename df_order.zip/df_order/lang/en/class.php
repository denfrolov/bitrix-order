<?$MESS["EMAIL"] = "email";
$MESS["PHONE"] = "phone";
